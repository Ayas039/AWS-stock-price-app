document.getElementById("fetchButton").addEventListener("click", async () => {
  console.log("Fetch button clicked"); // Log button click event
  const ticker = document.getElementById("stockTicker").value.trim();
  console.log("Ticker entered:", ticker); // Log entered ticker

  const resultDiv = document.getElementById("result");
  const errorDiv = document.getElementById("error");

  resultDiv.innerHTML = ""; // Clear previous results
  errorDiv.innerHTML = ""; // Clear previous errors

  if (!ticker) {
    errorDiv.innerText = "Please enter a stock ticker.";
    console.log("Error: No ticker entered");
    return;
  }

  try {
    const response = await fetch(`https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${ticker}&apikey=YOUR_API_KEY`);
    console.log("API Response received:", response);
    const data = await response.json();
    console.log("Parsed data:", data);

    if (data["Global Quote"] && data["Global Quote"]["01. symbol"]) {
      const symbol = data["Global Quote"]["01. symbol"];
      const price = data["Global Quote"]["05. price"];
      resultDiv.innerHTML = `<h2>${symbol}</h2><p>Current Price: $${price}</p>`;
    } else {
      errorDiv.innerText = "Invalid ticker. Please enter a valid U.S. stock symbol.";
      console.log("Error: Invalid ticker entered");
    }
  } catch (error) {
    errorDiv.innerText = "Failed to fetch stock data. Please try again.";
    console.error("Error fetching stock data:", error); // Log the error
  }
});
